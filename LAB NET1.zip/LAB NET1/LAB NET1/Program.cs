﻿using System;
using System.Text;
class Program
{
    // Коефіцієнти для конвертації
    const double KmInMile = 1.609344;
    const double KgInPound = 0.45359237;

    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        bool isRunning = true;

        while (isRunning)
        {
            Console.WriteLine("\n=== Конвертер величин ===");
            Console.WriteLine("1. км -> милі");
            Console.WriteLine("2. милі -> км");
            Console.WriteLine("3. кг -> фунти");
            Console.WriteLine("4. фунти -> кг");
            Console.WriteLine("5. °C -> °F");
            Console.WriteLine("6. °F -> °C");
            Console.WriteLine("0. Вихід");

            int choice = ReadInt("Ваш вибір: ", 0, 6);

            switch (choice)
            {
                case 1:
                    ConvertKmToMiles();
                    break;

                case 2:
                    ConvertMilesToKm();
                    break;

                case 3:
                    ConvertKgToPounds();
                    break;

                case 4:
                    ConvertPoundsToKg();
                    break;

                case 5:
                    ConvertCelsiusToFahrenheit();
                    break;

                case 6:
                    ConvertFahrenheitToCelsius();
                    break;

                case 0:
                    isRunning = false;
                    break;
            }
        }

        Console.WriteLine("Роботу завершено.");
    }

    // Конвертація кілометрів у милі
    static void ConvertKmToMiles()
    {
        double km = ReadDouble("Введіть кілометри: ");

        if (km < 0)
        {
            Console.WriteLine("Відстань не може бути від'ємною.");
            return;
        }

        double miles = KmToMiles(km);
        Console.WriteLine($"{km} км = {miles:F2} милі");
    }
    // Конвертація миль у кілометри
    static void ConvertMilesToKm()
    {
        double miles = ReadDouble("Введіть милі: ");

        if (miles < 0)
        {
            Console.WriteLine("Відстань не може бути від'ємною.");
            return;
        }

        double km = MilesToKm(miles);
        Console.WriteLine($"{miles} милі = {km:F2} км");
    }
    // Конвертація кілограмів у фунти
    static void ConvertKgToPounds()
    {
        double kg = ReadDouble("Введіть кілограми: ");

        if (kg < 0)
        {
            Console.WriteLine("Маса не може бути від'ємною.");
            return;
        }

        double pounds = KgToPounds(kg);
        Console.WriteLine($"{kg} кг = {pounds:F2} фунти");
    }
    // Конвертація фунтів у кілограми
    static void ConvertPoundsToKg()
    {
        double pounds = ReadDouble("Введіть фунти: ");

        if (pounds < 0)
        {
            Console.WriteLine("Маса не може бути від'ємною.");
            return;
        }

        double kg = PoundsToKg(pounds);
        Console.WriteLine($"{pounds} фунти = {kg:F2} кг");
    }
    // Конвертація градусів у фаренгейти
    static void ConvertCelsiusToFahrenheit()
    {
        double celsius = ReadDouble("Введіть температуру °C: ");
        // Перевірка абсолютного нуля
        if (celsius < -273.15)
        {
            Console.WriteLine("Температура не може бути нижчою за абсолютний нуль.");
            return;
        }

        double fahrenheit = CelsiusToFahrenheit(celsius);
        Console.WriteLine($"{celsius} °C = {fahrenheit:F2} °F");
    }
    // Конвертація фаренгейта у цельсії
    static void ConvertFahrenheitToCelsius()
    {
        double fahrenheit = ReadDouble("Введіть температуру °F: ");
        // Перевірка абсолютного нуля
        if (fahrenheit < -459.67)
        {
            Console.WriteLine("Температура не може бути нижчою за абсолютний нуль.");
            return;
        }

        double celsius = FahrenheitToCelsius(fahrenheit);
        Console.WriteLine($"{fahrenheit} °F = {celsius:F2} °C");
    }
    // Формула: кілометри - милі
    static double KmToMiles(double km)
    {
        return km / KmInMile;
    }
    // Формула: милі - кілометри
    static double MilesToKm(double miles)
    {
        return miles * KmInMile;
    }
    // Формула: кілограми - фунти
    static double KgToPounds(double kg)
    {
        return kg / KgInPound;
    }
    // Формула: фунти - кілограми
    static double PoundsToKg(double pounds)
    {
        return pounds * KgInPound;
    }
    // Формула: цельсій - фаренгейт
    static double CelsiusToFahrenheit(double celsius)
    {
        return celsius * 9 / 5 + 32;
    }
    // Формула: фаренгейт - цельсій
    static double FahrenheitToCelsius(double fahrenheit)
    {
        return (fahrenheit - 32) * 5 / 9;
    }
    // Зчитування цілого числа у заданому діапазоні
    static int ReadInt(string prompt, int min, int max)
    {
        while (true)
        {
            Console.Write(prompt);
            string? input = Console.ReadLine();
            // Перевірка, чи введено правильне число від 0 до 6
            if (int.TryParse(input, out int value) &&
                value >= min &&
                value <= max)
            {
                return value;
            }

            Console.WriteLine($"Некоректне значення. Введіть число від {min} до {max}.");
        }
    }
    // Зчитування дробового числа
    static double ReadDouble(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            string? input = Console.ReadLine();
            // Перевірка, чи користувач ввів число
            if (double.TryParse(input, out double value))
            {
                return value;
            }

            Console.WriteLine("Некоректне значення. Введіть число.");
        }
    }
}