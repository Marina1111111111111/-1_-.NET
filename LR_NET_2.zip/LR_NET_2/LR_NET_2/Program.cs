﻿using System;
using System.Collections.Generic;
using System.Text;

// Рівні розробника
enum DeveloperLevel
{
    Junior = 1,
    Middle = 2,
    Senior = 3
}
// Помилка якщо зарплата неправильна
class InvalidSalaryException : Exception
{
    public InvalidSalaryException()
    {
    }
    public InvalidSalaryException(string message)
        : base(message)
    {
    }

    public InvalidSalaryException(string message, Exception inner)
        : base(message, inner)
    {
    }
}
// Базовий клас
class Employee : IComparable<Employee>
{
    private string _fullName;
    private double _baseSalary;

    public string FullName
    {
        get => _fullName;

        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("ПІБ не може бути порожнім.");

            _fullName = value;
        }
    }
    public double BaseSalary
    {
        get => _baseSalary;

        set
        {
            if (value <= 0)
                throw new InvalidSalaryException(
                    "Базова зарплата повинна бути більшою за 0.");

            _baseSalary = value;
        }
    }
    // Основний конструктор
    public Employee(string fullName, double baseSalary)
    {
        FullName = fullName;
        BaseSalary = baseSalary;
    }
    // Перевантажений конструктор
    public Employee(string fullName)
        : this(fullName, 10000)
    {
    }
    // Віртуальний метод
    public virtual double CalculateSalary()
    {
        return BaseSalary;
    }
    // Віртуальний метод виведення інформації
    public virtual void PrintInfo()
    {
        Console.WriteLine(
            $"Співробітник: {FullName}, " +
            $"базова зарплата: {BaseSalary:F2}, " +
            $"зарплата: {CalculateSalary():F2}");
    }
    // Порівняння працівників за зарплатою
    public int CompareTo(Employee? other)
    {
        if (other == null)
            return 1;

        return CalculateSalary().CompareTo(other.CalculateSalary());
    }
}
// Клас менеджера
class Manager : Employee
{
    private int _subordinatesCount;
    public int SubordinatesCount
    {
        get => _subordinatesCount;

        set
        {
            if (value < 0)
                throw new ArgumentOutOfRangeException(
                    nameof(SubordinatesCount),
                    "Кількість підлеглих не може бути від'ємною.");

            _subordinatesCount = value;
        }
    }
    // Надбавка за одного підлеглого
    public double BonusPerSubordinate { get; } = 1000;
    public Manager(
        string fullName,
        double baseSalary,
        int subordinatesCount)
        : base(fullName, baseSalary)
    {
        SubordinatesCount = subordinatesCount;
    }
    // Рахуємо зарплату менеджера
    public override double CalculateSalary()
    {
        return BaseSalary +
               SubordinatesCount * BonusPerSubordinate;
    }
    public override void PrintInfo()
    {
        Console.WriteLine(
            $"Менеджер: {FullName}, " +
            $"базова зарплата: {BaseSalary:F2}, " +
            $"підлеглих: {SubordinatesCount}, " +
            $"зарплата: {CalculateSalary():F2}");
    }
}
// Клас розробника
class Developer : Employee
{
    public DeveloperLevel Level { get; set; }
    public Developer(
        string fullName,
        double baseSalary,
        DeveloperLevel level)
        : base(fullName, baseSalary)
    {
        Level = level;
    }
    // Перевизначення розрахунку зарплати
    public override double CalculateSalary()
    {
        double levelBonus;

        switch (Level)
        {
            case DeveloperLevel.Junior:
                levelBonus = 0;
                break;

            case DeveloperLevel.Middle:
                levelBonus = 5000;
                break;

            case DeveloperLevel.Senior:
                levelBonus = 10000;
                break;

            default:
                levelBonus = 0;
                break;
        }

        return BaseSalary + levelBonus;
    }
    public override void PrintInfo()
    {
        Console.WriteLine(
            $"Розробник: {FullName}, " +
            $"рівень: {Level}, " +
            $"базова зарплата: {BaseSalary:F2}, " +
            $"зарплата: {CalculateSalary():F2}");
    }
}
class Program
{
    static void Main()
    {
        Console.InputEncoding = Encoding.UTF8;
        Console.OutputEncoding = Encoding.UTF8;
        // Список працівників
        List<Employee> employees = new()
        {
            new Manager("Іван Петренко", 30000, 5),

            new Developer(
                "Олена Коваль",
                25000,
                DeveloperLevel.Middle),

            new Developer(
                "Андрій Бондар",
                35000,
                DeveloperLevel.Senior),

            new Manager("Марія Шевченко", 28000, 3)
        };
        bool isRunning = true;
        while (isRunning)
        {
            Console.WriteLine("\n========== МЕНЮ ==========");
            Console.WriteLine("0. Вихід");
            Console.WriteLine("1. Додати співробітника");
            Console.WriteLine("2. Показати всіх співробітників");
            Console.WriteLine("3. Показати сумарний фонд зарплати");
            Console.WriteLine("4. Відсортувати за зарплатою");
            Console.WriteLine("==========================");

            int choice = ReadInt("Ваш вибір: ", 0, 4);

            switch (choice)
            {
                case 0:
                    isRunning = false;
                    break;

                case 1:
                    AddEmployee(employees);
                    break;

                case 2:
                    ShowEmployees(employees);
                    break;

                case 3:
                    ShowTotalSalary(employees);
                    break;

                case 4:
                    ShowSortedEmployees(employees);
                    break;
            }
        }

        Console.WriteLine("Програму завершено.");
    }
    // ДОДАВАННЯ СПІВРОБІТНИКА
    static void AddEmployee(List<Employee> employees)
    {
        try
        {
            Console.WriteLine("\nОберіть посаду:");
            Console.WriteLine("1. Manager");
            Console.WriteLine("2. Developer");

            int type = ReadInt("Ваш вибір: ", 1, 2);

            Console.Write("Введіть ПІБ: ");
            string fullName = Console.ReadLine() ?? "";

            double baseSalary =
                ReadDouble("Введіть базову зарплату: ");

            if (type == 1)
            {
                int count = ReadInt(
                    "Кількість підлеглих: ",
                    0,
                    int.MaxValue);

                Manager manager =
                    new Manager(
                        fullName,
                        baseSalary,
                        count);

                employees.Add(manager);
            }
            else
            {
                Console.WriteLine("\nРівень розробника:");
                Console.WriteLine("1. Junior");
                Console.WriteLine("2. Middle");
                Console.WriteLine("3. Senior");

                int levelNumber =
                    ReadInt("Ваш вибір: ", 1, 3);

                DeveloperLevel level =
                    (DeveloperLevel)levelNumber;

                Developer developer =
                    new Developer(
                        fullName,
                        baseSalary,
                        level);

                employees.Add(developer);
            }

            Console.WriteLine(
                "Співробітника успішно додано.");
        }

        catch (InvalidSalaryException ex)
        {
            Console.WriteLine(
                $"Помилка зарплати: {ex.Message}");
        }

        catch (ArgumentException ex)
        {
            Console.WriteLine(
                $"Помилка даних: {ex.Message}");
        }

        catch (Exception ex)
        {
            Console.WriteLine(
                $"Непередбачена помилка: {ex.Message}");
        }

        finally
        {
            Console.WriteLine(
                "Операцію додавання завершено.");
        }
    }
    // ПОКАЗАТИ ВСІХ
    static void ShowEmployees(List<Employee> employees)
    {
        Console.WriteLine(
            "\n=== СПИСОК СПІВРОБІТНИКІВ ===");

        if (employees.Count == 0)
        {
            Console.WriteLine("Список порожній.");
            return;
        }

        foreach (Employee employee in employees)
        {
            employee.PrintInfo();
        }
    }
    // ФОНД ЗАРПЛАТИ
    static void ShowTotalSalary(List<Employee> employees)
    {
        double total = 0;

        foreach (Employee employee in employees)
        {
            total += employee.CalculateSalary();
        }

        Console.WriteLine(
            $"\nСумарний фонд заробітної плати: {total:F2}");
    }
    // СОРТУВАННЯ
    static void ShowSortedEmployees(
        List<Employee> employees)
    {
        List<Employee> sortedEmployees =
            new List<Employee>(employees);

        // Сортування зарплати від меншої до більшої
        sortedEmployees.Sort();
        // Від більшої зарплати до меншої
        sortedEmployees.Reverse();

        Console.WriteLine(
            "\n=== СПІВРОБІТНИКИ ЗА ЗАРПЛАТОЮ ===");

        foreach (Employee employee in sortedEmployees)
        {
            employee.PrintInfo();
        }
    }
    // Введення цілого числа (int)
    static int ReadInt(
        string message,
        int min,
        int max)
    {
        while (true)
        {
            Console.Write(message);

            string? input = Console.ReadLine();

            if (int.TryParse(input, out int value)
                && value >= min
                && value <= max)
            {
                return value;
            }

            Console.WriteLine(
                "Помилка. Введіть коректне ціле число.");
        }
    }
    // Введення дробового числа (DOUBLE)
    static double ReadDouble(string message)
    {
        while (true)
        {
            Console.Write(message);

            string? input = Console.ReadLine();

            if (double.TryParse(input, out double value))
            {
                return value;
            }
            Console.WriteLine(
                "Помилка. Введіть число.");
        }
    }
}